from django.db import models

from django.contrib.auth.models import AbstractUser
from django.db import models

class User(AbstractUser):
    first_name = None
    last_name = None
    ism = models.CharField(max_length=150)
    bio = models.CharField(max_length=150)
    date_of_birth = models.DateField(null=True, blank=True)
    password = models.CharField(max_length=8)
    is_staff = models.BooleanField(default=False)

class Faollar(models.Model):
    first_name = models.CharField(max_length=150)
    last_name = models.CharField(max_length=150)
    father_name = models.CharField(max_length=150)
    birth_date = models.CharField(max_length=16)
    province = models.CharField(max_length=150)
    city = models.CharField(max_length=150)
    phone_number = models.CharField(max_length=150)
    user_type = models.CharField(max_length=150)
    status = models.BooleanField(default=False)
    can_participate_in_events = models.BooleanField(default=False)