from rest_framework.serializers import ModelSerializer

from .models import CourseCategory, Course, CourseDepartment, CoursePart
