from django.shortcuts import render

from rest_framework.viewsets import ModelViewSet
from rest_framework.permissions import IsAuthenticated as IA
from rest_framework.authentication import BasicAuthentication

from .serializers import *

from course.models import *
from users.models import Faollar

from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from .serializers import LoginSerializer

class LoginView(APIView):
    def post(self, request):
        serializer = LoginSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.validated_data
            # You can perform additional tasks here if needed
            return Response({"message": "Login successful"}, status=status.HTTP_200_OK)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class IsAuthenticated(IA):
    def has_permission(self, request, view):
        # return True
        if request.method == "GET":
            return True
        return bool(request.user and request.user.is_authenticated and request.user.is_staff)


class UserViewset(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    serializer_class = UserModelSerializer
    queryset = User.objects


class CategoryViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = CourseCategorySerializer
    queryset = CourseCategory.objects

class CourseViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = CourseSerializer
    queryset = Course.objects

class CourseDepartmentViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = CourseDepartmentSerializer
    queryset = CourseDepartment.objects

class CoursePartViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = CoursePartSerializer
    queryset = CoursePart.objects

class NewsCategoryViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = NewsCategorySerializer
    queryset = NewsCategory.objects

class NewsViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = NewsSerializer
    queryset = News.objects

class FaollarViewSet(ModelViewSet):
    authentication_classes = [BasicAuthentication]
    # permission_classes = [IsAuthenticated]
    serializer_class = FaollarSerializer
    queryset = Faollar.objects
    


    