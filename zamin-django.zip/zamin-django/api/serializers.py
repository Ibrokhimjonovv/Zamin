from rest_framework.serializers import ModelSerializer, ReadOnlyField

from course.models import CourseCategory, Course, CourseDepartment, CoursePart, NewsCategory, News
from users.models import Faollar, User


from rest_framework import serializers
from django.contrib.auth import authenticate

class LoginSerializer(serializers.Serializer):
    username = serializers.CharField()
    password = serializers.CharField()

    def validate(self, data):
        uname = data.get('username')
        print("Username:", uname)
        pword = data.get('password')
        print("Password:", pword)

        if uname and pword:
            user = authenticate(username=uname, password=pword)
            if user:
                print("Authentication successful")
                if not user.is_active:
                    raise serializers.ValidationError("User account is disabled.")
                return data
            else:
                print("Authentication failed")
                raise serializers.ValidationError("Unable to log in with provided credentials.")
        else:
            raise serializers.ValidationError("Must include 'username' and 'password'.")


class UserModelSerializer(ModelSerializer):
    class Meta:
        model = User
        fields ="__all__"

class CourseSerializer(ModelSerializer):
    class Meta:
        model = Course
        fields = "__all__"

class CourseCategorySerializer(ModelSerializer):
    courses = CourseSerializer(many=True, read_only=True)

    class Meta:
        model = CourseCategory
        fields = "__all__"


class CourseDepartmentSerializer(ModelSerializer):
    class Meta:
        model = CourseDepartment
        fields = "__all__"

class CoursePartSerializer(ModelSerializer):
    class Meta:
        model = CoursePart
        fields = "__all__"

class NewsCategorySerializer(ModelSerializer):
    class Meta:
        model = NewsCategory
        fields = "__all__"

class NewsSerializer(ModelSerializer):
    class Meta:
        model = News
        fields = "__all__"

class FaollarSerializer(ModelSerializer):
    class Meta:
        model = Faollar
        fields = "__all__"