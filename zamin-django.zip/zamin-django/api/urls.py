from django.urls import path, include
from rest_framework_simplejwt.views import TokenObtainPairView, TokenRefreshView
from rest_framework.routers import DefaultRouter
from .views import *

router = DefaultRouter()
router.register("category", CategoryViewSet)
router.register("course", CourseViewSet)
router.register("course-department", CourseDepartmentViewSet)
router.register("course-part", CoursePartViewSet)
router.register("news-category", NewsCategoryViewSet)
router.register("news", NewsViewSet)
router.register("faollar", FaollarViewSet)
router.register("users", UserViewset)

urlpatterns = [
    path("", include(router.urls)),
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('login/', LoginView.as_view(), name='login'),
]